# GerenciamentoDeUmaPousada
 Desenvolver um programa para gerenciamento básico de uma pousada. Implementar persistência de dados em arquivos texto tabulados.

# Autores

- Gabriel Ponzoni
- Gaspar